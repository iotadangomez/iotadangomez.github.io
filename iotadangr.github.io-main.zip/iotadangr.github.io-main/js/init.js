// @ts-ignore
firebase.initializeApp({
   apiKey: "AIzaSyAmP4vCh95D1xPu6lGpIgVoXc6GZ7K33U0",
    authDomain: "iotadangr-1c1c6.firebaseapp.com",
    projectId: "iotadangr-1c1c6",
    storageBucket: "iotadangr-1c1c6.appspot.com",
    messagingSenderId: "72121991817",
    appId: "1:72121991817:web:725125815280028f87bc58"

});
